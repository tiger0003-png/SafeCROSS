/**
 * SafeCross CSV Report Exporter Utility
 * Generates and triggers browser download of scan history items as CSV.
 */

import { HistoryItem } from '../types/safecross';

export interface CsvExportOptions {
  filenamePrefix?: string;
  customTitle?: string;
}

/**
 * Escapes a CSV cell value following RFC 4180 standards.
 */
function escapeCsvCell(value: unknown): string {
  if (value === null || value === undefined) {
    return '""';
  }
  const str = String(value);
  // If the cell contains quotes, commas, or newlines, wrap in quotes and escape internal quotes
  return `"${str.replace(/"/g, '""')}"`;
}

/**
 * Converts a list of HistoryItems to standard CSV string content.
 */
export function generateHistoryCsv(items: HistoryItem[], customTitle?: string): string {
  const headers = [
    'Scan ID',
    'Timestamp (ISO)',
    'Formatted Date',
    'Target Asset',
    'Asset Type',
    'Risk Category',
    'Risk Score (0-100)',
    'Assessment Summary',
    'Detected Indicators',
    'Engine / Source',
    'SSL / TLS Status',
    'Package / Hash Identifier',
  ];

  const rows = items.map((item) => {
    const formattedDate = new Date(item.timestamp).toLocaleString();
    const indicatorsJoined = (item.indicators || []).join('; ');
    const engine = item.details?.engine || 'Local Pattern Heuristics';
    const ssl = item.details?.sslStatus || 'N/A';
    const hashOrPkg = item.details?.sha256 || item.details?.packageName || 'N/A';

    return [
      escapeCsvCell(item.id),
      escapeCsvCell(item.timestamp),
      escapeCsvCell(formattedDate),
      escapeCsvCell(item.target),
      escapeCsvCell(item.type),
      escapeCsvCell(item.category),
      escapeCsvCell(item.score),
      escapeCsvCell(item.summary),
      escapeCsvCell(indicatorsJoined),
      escapeCsvCell(engine),
      escapeCsvCell(ssl),
      escapeCsvCell(hashOrPkg),
    ].join(',');
  });

  const titleRow = customTitle ? `# ${customTitle}\n# Generated: ${new Date().toISOString()}\n# Record Count: ${items.length}\n` : '';

  return `${titleRow}${headers.join(',')}\n${rows.join('\n')}`;
}

/**
 * Triggers a client-side browser file download for the CSV data.
 */
export function downloadCsvReport(
  items: HistoryItem[],
  options: CsvExportOptions = {}
): { success: boolean; count: number; filename: string } {
  const { filenamePrefix = 'safecross_threat_report', customTitle } = options;
  const dateStamp = new Date().toISOString().slice(0, 10);
  const timeStamp = new Date().toTimeString().slice(0, 8).replace(/:/g, '-');
  const filename = `${filenamePrefix}_${dateStamp}_${timeStamp}.csv`;

  const csvContent = generateHistoryCsv(items, customTitle);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

  // Use URL.createObjectURL for reliable browser download
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  link.style.display = 'none';

  document.body.appendChild(link);
  link.click();

  // Clean up URL object after brief delay
  setTimeout(() => {
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, 150);

  return {
    success: true,
    count: items.length,
    filename,
  };
}
